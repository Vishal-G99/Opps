# Module 11 — Method References

> Part of: **Java Stream API — Complete Reference Guide**
> A method reference is shorthand for a lambda that does nothing but call an existing method. All four kinds compile to the same functional-interface targets as an equivalent lambda.

---

## 1. `Class::staticMethod`

References a static method — the compiler infers the functional interface's parameters map directly to the static method's parameters.

```java
Function<String, Integer> parse = Integer::parseInt;   // same as: s -> Integer.parseInt(s)
Stream.of("1", "2", "3").map(Integer::parseInt).forEach(System.out::println);
```

## 2. `object::instanceMethod`

References an instance method on a **specific, already-existing** object — the functional interface's parameters map to that method's parameters (the object itself is fixed/captured).

```java
String prefix = "Hello, ";
Function<String, String> greeter = prefix::concat; // same as: s -> prefix.concat(s)
System.out.println(greeter.apply("World")); // Hello, World

List<String> results = new ArrayList<>();
Stream.of("a", "b").forEach(results::add); // results::add is bound to this specific list
```

## 3. `Class::instanceMethod`

References an instance method **without** a specific object — the functional interface's **first** parameter becomes the receiver object, and any remaining parameters map to the method's actual parameters.

```java
Function<String, Integer> length = String::length; // same as: s -> s.length()
Stream.of("a", "bb", "ccc").map(String::length).forEach(System.out::println); // 1, 2, 3

Comparator<String> byAlpha = String::compareTo; // same as: (s1, s2) -> s1.compareTo(s2)
```

**This is the one most people find confusing** — `String::length` looks like a static reference but isn't; the stream's element itself becomes the implicit receiver (`s.length()`), and there just happens to be no extra parameter needed since `length()` takes none.

## 4. `Class::new` (constructor reference)

References a constructor — the functional interface's parameters map to a matching constructor's parameters.

```java
Supplier<ArrayList<String>> listMaker = ArrayList::new; // same as: () -> new ArrayList<>()

record Point(int x, int y) {}
BiFunction<Integer, Integer, Point> pointMaker = Point::new; // same as: (x, y) -> new Point(x, y)
Point p = pointMaker.apply(3, 4);

// Common stream usage: converting a stream of one type into objects of another
Stream.of("Alice", "Bob")
      .map(Point::new) // only valid if Point had a single-String constructor — illustrative
      .forEach(System.out::println);

// Very common real pattern — array constructor reference for toArray()
String[] arr = Stream.of("a", "b").toArray(String[]::new);
```

## Quick Decision Guide

```
Does the method belong to the class itself (static)?          -> Class::staticMethod
Do you already have a specific object to call it on?           -> object::instanceMethod
Is the object the stream ELEMENT ITSELF (no object in hand)?    -> Class::instanceMethod
Are you constructing a NEW object?                              -> Class::new
```

---

**Next: Module 12 — Parallel Streams** (parallel execution, ForkJoinPool, ordering, thread safety, and performance trade-offs).
