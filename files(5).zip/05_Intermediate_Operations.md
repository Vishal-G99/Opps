# Module 5 — Intermediate Operations

> Part of: **Java Stream API — Complete Reference Guide**
> All operations here are **lazy** — they build the pipeline but don't execute until a terminal operation runs (Module 1/2).

---

## 1. `filter(Predicate<T>)`

Keeps only elements matching the predicate.

```java
List.of(1, 2, 3, 4, 5).stream()
    .filter(n -> n % 2 == 0)
    .forEach(System.out::println); // 2, 4
```

## 2. `map(Function<T,R>)`

Transforms each element into another value (possibly a different type).

```java
List.of("a", "bb", "ccc").stream()
    .map(String::length)
    .forEach(System.out::println); // 1, 2, 3
```

## 3. `flatMap(Function<T, Stream<R>>)`

Flattens a stream-of-streams into a single stream — essential for nested collections.

```java
List<List<Integer>> nested = List.of(List.of(1, 2), List.of(3, 4), List.of(5));

List<Integer> flat = nested.stream()
        .flatMap(List::stream)
        .collect(Collectors.toList());
System.out.println(flat); // [1, 2, 3, 4, 5]
```

## 4. `mapToInt(ToIntFunction<T>)`

Converts a `Stream<T>` to an `IntStream` (unboxing), enabling numeric methods like `sum()`.

```java
int totalLength = List.of("a", "bb", "ccc").stream()
        .mapToInt(String::length)
        .sum();
System.out.println(totalLength); // 6
```

## 5. `mapToLong(ToLongFunction<T>)`

Same idea, producing a `LongStream`.

```java
long totalMillis = List.of(1000L, 2000L).stream()
        .mapToLong(Long::longValue)
        .sum();
```

## 6. `mapToDouble(ToDoubleFunction<T>)`

Same idea, producing a `DoubleStream`.

```java
double avgPrice = List.of(9.99, 19.99).stream()
        .mapToDouble(Double::doubleValue)
        .average()
        .orElse(0.0);
```

## 7. `flatMapToInt` / `flatMapToLong` / `flatMapToDouble`

`flatMap` variants that flatten into a **primitive** stream instead of `Stream<T>`.

```java
List<int[]> arrays = List.of(new int[]{1, 2}, new int[]{3, 4});

int sum = arrays.stream()
        .flatMapToInt(IntStream::of)
        .sum();
System.out.println(sum); // 10
```

## 8. `distinct()`

Removes duplicate elements (using `equals()`). **Stateful** (Module 13) — must buffer seen elements.

```java
Stream.of(1, 2, 2, 3, 3, 3).distinct().forEach(System.out::println); // 1, 2, 3
```

## 9. `sorted()`

Sorts elements — natural order, or via a supplied `Comparator`. **Stateful** — must see the whole stream before emitting the first element.

```java
Stream.of(5, 3, 1, 4, 2).sorted().forEach(System.out::println); // 1, 2, 3, 4, 5

Stream.of("bb", "a", "ccc")
      .sorted(Comparator.comparingInt(String::length))
      .forEach(System.out::println); // a, bb, ccc
```

## 10. `peek(Consumer<T>)`

Performs a side-effecting action on each element **without changing the stream** — mainly for debugging. Because it's lazy, it only actually runs if a terminal operation causes traversal, and (since Java 9) may be optimized away entirely if its result is provably unused.

```java
long count = Stream.of(1, 2, 3)
        .peek(n -> System.out.println("peeking: " + n))
        .filter(n -> n > 1)
        .count();
```

## 11. `limit(long)`

Truncates the stream to at most N elements. **Short-circuiting** — can stop an infinite stream.

```java
Stream.iterate(1, n -> n + 1).limit(3).forEach(System.out::println); // 1, 2, 3
```

## 12. `skip(long)`

Discards the first N elements.

```java
Stream.of(1, 2, 3, 4, 5).skip(2).forEach(System.out::println); // 3, 4, 5
```

## 13. `takeWhile(Predicate<T>)` (Java 9+)

Takes elements **while** the predicate holds, then stops entirely at the first failure — unlike `filter()`, which checks every element.

```java
Stream.of(1, 2, 3, 4, 1, 2)
      .takeWhile(n -> n < 4)
      .forEach(System.out::println); // 1, 2, 3 (stops at the FIRST 4, ignores the later 1, 2)
```

## 14. `dropWhile(Predicate<T>)` (Java 9+)

Drops elements while the predicate holds, then keeps everything from the first failure onward.

```java
Stream.of(1, 2, 3, 4, 1, 2)
      .dropWhile(n -> n < 4)
      .forEach(System.out::println); // 4, 1, 2
```

## 15. `unordered()`

Hints that the stream's encounter order doesn't matter, potentially enabling performance optimizations (especially for parallel streams, Module 12) — doesn't reorder elements itself, just relaxes the ordering guarantee for subsequent operations.

```java
Stream.of(1, 2, 3).unordered().forEach(System.out::println);
```

---

**Next: Module 6 — Terminal Operations** (forEach, reduce, collect, matching, finding — every way to end a pipeline).
