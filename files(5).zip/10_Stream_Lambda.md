# Module 10 — Stream + Lambda (Functional Interfaces)

> Part of: **Java Stream API — Complete Reference Guide**
> Every lambda you pass into a stream operation implements one of these `java.util.function` interfaces under the hood.

---

## 1. `Predicate<T>` — `boolean test(T t)`

Used by `filter()`, `anyMatch()`, `allMatch()`, `noneMatch()`, `takeWhile()`, `dropWhile()`.

```java
Predicate<Integer> isEven = n -> n % 2 == 0;
Stream.of(1, 2, 3, 4).filter(isEven).forEach(System.out::println); // 2, 4

// Combinators: and(), or(), negate()
Predicate<Integer> isPositive = n -> n > 0;
Predicate<Integer> isEvenAndPositive = isEven.and(isPositive);
Predicate<Integer> isOdd = isEven.negate();
```

## 2. `Function<T,R>` — `R apply(T t)`

Used by `map()`, `flatMap()` (returning a stream), `reduce()`'s combiner in some overloads.

```java
Function<String, Integer> length = String::length;
Stream.of("a", "bb").map(length).forEach(System.out::println); // 1, 2

// Composition: andThen(), compose()
Function<Integer, Integer> addOne = n -> n + 1;
Function<Integer, Integer> square = n -> n * n;
Function<Integer, Integer> addThenSquare = addOne.andThen(square); // (n+1)^2
System.out.println(addThenSquare.apply(2)); // 9
```

## 3. `Consumer<T>` — `void accept(T t)`

Used by `forEach()`, `peek()`, `ifPresent()`.

```java
Consumer<String> printer = System.out::println;
Stream.of("a", "b").forEach(printer);

// Chaining: andThen()
Consumer<String> upperPrinter = s -> System.out.println(s.toUpperCase());
Stream.of("a").forEach(printer.andThen(upperPrinter));
```

## 4. `Supplier<T>` — `T get()`

Used by `Stream.generate()`, `orElseGet()`, `Collectors.toCollection()`.

```java
Supplier<Double> randomSupplier = Math::random;
Stream.generate(randomSupplier).limit(2).forEach(System.out::println);
```

## 5. `UnaryOperator<T>` — extends `Function<T,T>`, input/output same type

Used by `Stream.iterate()`, `replaceAll()`.

```java
UnaryOperator<Integer> doubleIt = n -> n * 2;
Stream.iterate(1, doubleIt).limit(4).forEach(System.out::println); // 1, 2, 4, 8
```

## 6. `BinaryOperator<T>` — extends `BiFunction<T,T,T>`, both inputs and output same type

Used by `reduce()`'s accumulator, `Collectors.reducing()`, `toMap()`'s merge function.

```java
BinaryOperator<Integer> sum = Integer::sum;
int total = Stream.of(1, 2, 3).reduce(0, sum);
System.out.println(total); // 6

// Static helpers
BinaryOperator<Integer> max = BinaryOperator.maxBy(Comparator.naturalOrder());
```

## 7. `Comparator<T>` — `int compare(T a, T b)`

Used by `sorted()`, `min()`, `max()`, and as a `Collectors.groupingBy`/`maxBy`/`minBy` argument.

```java
Comparator<String> byLength = Comparator.comparingInt(String::length);
Stream.of("ccc", "a", "bb").sorted(byLength).forEach(System.out::println); // a, bb, ccc

// Chaining: thenComparing(), reversed()
Comparator<String> byLengthThenAlpha = byLength.thenComparing(Comparator.naturalOrder());
Comparator<String> descending = byLength.reversed();
```

## Summary Table

| Interface | Method | Arity | Used by |
|---|---|---|---|
| `Predicate<T>` | `test(T)` → `boolean` | 1 in | `filter`, `anyMatch`, `allMatch`, `noneMatch` |
| `Function<T,R>` | `apply(T)` → `R` | 1 in, 1 out (diff type) | `map`, `flatMap` |
| `Consumer<T>` | `accept(T)` → `void` | 1 in, no out | `forEach`, `peek` |
| `Supplier<T>` | `get()` → `T` | 0 in, 1 out | `generate`, `orElseGet` |
| `UnaryOperator<T>` | `apply(T)` → `T` | 1 in, 1 out (same type) | `iterate` |
| `BinaryOperator<T>` | `apply(T,T)` → `T` | 2 in (same type), 1 out (same type) | `reduce` |
| `Comparator<T>` | `compare(T,T)` → `int` | 2 in, 1 out (int) | `sorted`, `min`, `max` |

---

**Next: Module 11 — Method References** (the four kinds, and how each maps back to a functional interface).
