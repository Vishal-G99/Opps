# Module 3 — Stream Types

> Part of: **Java Stream API — Complete Reference Guide**
> **⚠️ Additions to your original roadmap:** Your list had `Stream<T>`, `IntStream`, `LongStream`, `DoubleStream`. That's correct for the four *concrete* stream types, but it's missing the **root interface** they all implement (`BaseStream`) and the **Builder** / **SummaryStatistics** supporting types that a complete picture of "Stream Types" should include. All are added below.

---

## 1. `BaseStream<T, S extends BaseStream<T,S>>` — the root interface *(missing from original list)*

Every stream type — `Stream<T>`, `IntStream`, `LongStream`, `DoubleStream` — extends `BaseStream`. It defines the operations common to all of them regardless of element type:

```java
public interface BaseStream<T, S extends BaseStream<T, S>> extends AutoCloseable {
    Iterator<T> iterator();
    Spliterator<T> spliterator();
    boolean isParallel();
    S sequential();
    S parallel();
    S unordered();
    S onClose(Runnable closeHandler);
    void close();
}
```

**Why this matters (frequently asked):** "What is the common parent of `Stream`, `IntStream`, `LongStream`, and `DoubleStream`?" → `BaseStream`. It's why `.parallel()`, `.sequential()`, `.isParallel()`, and `.close()` (Module 12) work identically across every stream type without each one redefining them.

```java
IntStream intStream = IntStream.of(1, 2, 3);
System.out.println(intStream.isParallel()); // false — inherited from BaseStream
```

## 2. `Stream<T>` — the general-purpose stream

Holds elements of any reference type `T`.

```java
Stream<String> names = Stream.of("Alice", "Bob", "Charlie");
names.map(String::toUpperCase).forEach(System.out::println);
// ALICE
// BOB
// CHARLIE
```

## 3. `IntStream` — primitive `int` stream

Avoids autoboxing every element into `Integer`, which matters for performance in numeric-heavy pipelines. Has extra numeric methods (`sum()`, `average()`, `range()`) not present on `Stream<T>`.

```java
int total = IntStream.rangeClosed(1, 5).sum();
System.out.println(total); // 15
```

## 4. `LongStream` — primitive `long` stream

Same idea as `IntStream`, for 64-bit integers — e.g., counting very large ranges or working with epoch millisecond timestamps.

```java
long bigSum = LongStream.rangeClosed(1L, 1_000_000_000L).sum();
System.out.println(bigSum);
```

## 5. `DoubleStream` — primitive `double` stream

For floating-point numeric pipelines.

```java
double avg = DoubleStream.of(1.5, 2.5, 3.0).average().orElse(0.0);
System.out.println(avg); // 2.333333333333333
```

## 6. `Stream.Builder<T>` / `IntStream.Builder` / `LongStream.Builder` / `DoubleStream.Builder` *(missing from original list)*

An imperative way to construct a stream one element at a time, when you don't have a ready-made source collection.

```java
Stream<String> built = Stream.<String>builder()
        .add("x")
        .add("y")
        .add("z")
        .build();
built.forEach(System.out::println); // x, y, z

IntStream.Builder intBuilder = IntStream.builder();
intBuilder.add(1).add(2).add(3);
System.out.println(intBuilder.build().sum()); // 6
```

## 7. `IntSummaryStatistics` / `LongSummaryStatistics` / `DoubleSummaryStatistics` *(missing — supports Module 7)*

Returned by `summaryStatistics()` on a primitive stream — bundles count, sum, min, max, and average into one object computed in a single pass.

```java
IntSummaryStatistics stats = IntStream.of(4, 8, 15, 16, 23, 42).summaryStatistics();
System.out.println(stats.getCount());   // 6
System.out.println(stats.getSum());     // 108
System.out.println(stats.getMin());     // 4
System.out.println(stats.getMax());     // 42
System.out.println(stats.getAverage()); // 18.0
```

## Summary Table — All Stream-Related Types

| Type | Category | Element Type |
|---|---|---|
| `BaseStream<T,S>` | Root interface | Generic — parent of all four below |
| `Stream<T>` | Concrete stream | Reference type `T` |
| `IntStream` | Concrete stream | primitive `int` |
| `LongStream` | Concrete stream | primitive `long` |
| `DoubleStream` | Concrete stream | primitive `double` |
| `Stream.Builder<T>` | Construction helper | Builds a `Stream<T>` |
| `IntStream.Builder` | Construction helper | Builds an `IntStream` |
| `LongStream.Builder` | Construction helper | Builds a `LongStream` |
| `DoubleStream.Builder` | Construction helper | Builds a `DoubleStream` |
| `IntSummaryStatistics` | Result object | Summary of an `IntStream` |
| `LongSummaryStatistics` | Result object | Summary of a `LongStream` |
| `DoubleSummaryStatistics` | Result object | Summary of a `DoubleStream` |

## Converting Between Stream Types

```java
Stream<Integer> boxed = IntStream.range(1, 5).boxed();       // IntStream -> Stream<Integer>
IntStream unboxed = boxed.mapToInt(Integer::intValue);        // Stream<Integer> -> IntStream
LongStream asLong = IntStream.range(1, 5).asLongStream();      // IntStream -> LongStream
DoubleStream asDouble = IntStream.range(1, 5).asDoubleStream(); // IntStream -> DoubleStream
```

---

**Next: Module 4 — Creating Streams** (every factory method, with examples).
