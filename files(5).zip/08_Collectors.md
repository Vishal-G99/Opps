# Module 8 — Collectors

> Part of: **Java Stream API — Complete Reference Guide**
> All examples use a shared sample dataset:

```java
record Employee(String name, String department, double salary) {}

List<Employee> employees = List.of(
    new Employee("Alice", "Engineering", 95000),
    new Employee("Bob", "Engineering", 85000),
    new Employee("Charlie", "Sales", 65000),
    new Employee("Dave", "Sales", 70000),
    new Employee("Eve", "HR", 60000)
);
```

---

## 1. `toList()`

```java
List<String> names = employees.stream().map(Employee::name).collect(Collectors.toList());
// [Alice, Bob, Charlie, Dave, Eve]
```

## 2. `toSet()`

```java
Set<String> departments = employees.stream().map(Employee::department).collect(Collectors.toSet());
// {Engineering, Sales, HR} (order not guaranteed — HashSet by default)
```

## 3. `toCollection(Supplier<C>)`

Collects into a specific collection type instead of the default `ArrayList`/`HashSet`.

```java
TreeSet<String> sortedDepts = employees.stream()
        .map(Employee::department)
        .collect(Collectors.toCollection(TreeSet::new));
// [Engineering, HR, Sales] — sorted, since TreeSet
```

## 4. `joining()`

Concatenates `CharSequence` elements, with optional delimiter/prefix/suffix.

```java
String csv = employees.stream().map(Employee::name).collect(Collectors.joining(", "));
System.out.println(csv); // Alice, Bob, Charlie, Dave, Eve

String bracketed = employees.stream().map(Employee::name)
        .collect(Collectors.joining(", ", "[", "]"));
System.out.println(bracketed); // [Alice, Bob, Charlie, Dave, Eve]
```

## 5. `counting()`

Counts elements — typically used as a downstream collector with `groupingBy`.

```java
long total = employees.stream().collect(Collectors.counting()); // 5
```

## 6. `summingInt()` / `summingLong()` / `summingDouble()`

```java
double totalSalary = employees.stream().collect(Collectors.summingDouble(Employee::salary));
System.out.println(totalSalary); // 375000.0
```

## 7. `averagingInt()` / `averagingLong()` / `averagingDouble()`

```java
double avgSalary = employees.stream().collect(Collectors.averagingDouble(Employee::salary));
System.out.println(avgSalary); // 75000.0
```

## 8. `summarizingInt()` / `summarizingLong()` / `summarizingDouble()`

Like `summaryStatistics()` (Module 7) but usable within `collect()` on a `Stream<T>` (not just a primitive stream).

```java
DoubleSummaryStatistics stats = employees.stream()
        .collect(Collectors.summarizingDouble(Employee::salary));
System.out.println(stats.getMax()); // 95000.0
```

## 9. `groupingBy()`

Groups elements by a classifier function into a `Map<K, List<T>>` by default.

```java
Map<String, List<Employee>> byDept = employees.stream()
        .collect(Collectors.groupingBy(Employee::department));
// {Engineering=[Alice, Bob], Sales=[Charlie, Dave], HR=[Eve]}
```

**With a downstream collector** (e.g., count per group instead of the full list):

```java
Map<String, Long> countByDept = employees.stream()
        .collect(Collectors.groupingBy(Employee::department, Collectors.counting()));
// {Engineering=2, Sales=2, HR=1}
```

## 10. `groupingByConcurrent()`

Concurrent-safe version of `groupingBy`, designed for use with **parallel streams** — returns a `ConcurrentMap`, avoiding the synchronization overhead a regular `HashMap`-backed collector would need under parallel execution.

```java
ConcurrentMap<String, List<Employee>> byDeptConcurrent = employees.parallelStream()
        .collect(Collectors.groupingByConcurrent(Employee::department));
```

## 11. `partitioningBy()`

Splits elements into exactly two groups (`true`/`false`) based on a predicate — always produces a `Map<Boolean, List<T>>` with **both** keys present, even if one group is empty.

```java
Map<Boolean, List<Employee>> partitioned = employees.stream()
        .collect(Collectors.partitioningBy(e -> e.salary() > 70000));
// {false=[Charlie, Dave, Eve], true=[Alice, Bob]}
```

## 12. `mapping()`

A downstream collector that transforms elements before they're collected — useful inside `groupingBy` to collect a *derived* value instead of the whole object.

```java
Map<String, List<String>> namesByDept = employees.stream()
        .collect(Collectors.groupingBy(Employee::department,
                 Collectors.mapping(Employee::name, Collectors.toList())));
// {Engineering=[Alice, Bob], Sales=[Charlie, Dave], HR=[Eve]}
```

## 13. `filtering()` (Java 9+)

A downstream collector that filters elements **within each group**, unlike `.filter()` on the stream itself (which would remove entire groups' source elements before grouping even happens).

```java
Map<String, List<Employee>> highEarnersByDept = employees.stream()
        .collect(Collectors.groupingBy(Employee::department,
                 Collectors.filtering(e -> e.salary() > 65000, Collectors.toList())));
// {Engineering=[Alice, Bob], Sales=[Dave], HR=[]}  <- HR group still present, just empty
```

## 14. `flatMapping()` (Java 9+)

Downstream collector version of `flatMap` — useful when each element maps to *multiple* values to collect within a group.

```java
record Department(String name, List<String> skills) {}
// e.g., flattening each employee's list of skills into one collected list per department
```

## 15. `collectingAndThen()`

Wraps a collector, applying a final transformation to its result — e.g., making a collected list immutable.

```java
List<String> immutableNames = employees.stream()
        .map(Employee::name)
        .collect(Collectors.collectingAndThen(Collectors.toList(), Collections::unmodifiableList));
```

## 16. `reducing()`

Collector version of the `reduce()` terminal operation — usable as a downstream collector inside `groupingBy`.

```java
Map<String, Optional<Employee>> highestPaidByDept = employees.stream()
        .collect(Collectors.groupingBy(Employee::department,
                 Collectors.reducing((e1, e2) -> e1.salary() >= e2.salary() ? e1 : e2)));
```

## 17. `maxBy()` / `minBy()`

```java
Map<String, Optional<Employee>> maxByDept = employees.stream()
        .collect(Collectors.groupingBy(Employee::department,
                 Collectors.maxBy(Comparator.comparingDouble(Employee::salary))));
```

## 18. `teeing()` (Java 12+)

Applies **two** collectors to the same stream simultaneously, then merges their results with a `BiFunction` — avoids needing two separate passes/streams.

```java
record MinMax(double min, double max) {}

MinMax result = employees.stream()
        .collect(Collectors.teeing(
                Collectors.minBy(Comparator.comparingDouble(Employee::salary)),
                Collectors.maxBy(Comparator.comparingDouble(Employee::salary)),
                (min, max) -> new MinMax(min.get().salary(), max.get().salary())
        ));
System.out.println(result); // MinMax[min=60000.0, max=95000.0]
```

## 19. `toMap()` (frequently used, worth adding beyond the original list)

```java
Map<String, Double> nameToSalary = employees.stream()
        .collect(Collectors.toMap(Employee::name, Employee::salary));
// {Alice=95000.0, Bob=85000.0, ...}

// With a merge function to handle duplicate keys (throws IllegalStateException without one)
Map<String, Double> deptToMaxSalary = employees.stream()
        .collect(Collectors.toMap(Employee::department, Employee::salary, Math::max));
```

---

**Next: Module 9 — Optional with Streams** (Optional&lt;T&gt;, OptionalInt, OptionalLong, OptionalDouble and how they interact with stream results).
