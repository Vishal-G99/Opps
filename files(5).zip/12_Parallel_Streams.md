# Module 12 — Parallel Streams

> Part of: **Java Stream API — Complete Reference Guide**

---

## 1. `parallel()`

Converts a sequential stream into a parallel one — subsequent operations may execute across multiple threads.

```java
List<Integer> numbers = IntStream.rangeClosed(1, 1000).boxed().collect(Collectors.toList());

long count = numbers.stream()
        .parallel()
        .filter(n -> n % 2 == 0)
        .count();
```

## 2. `parallelStream()`

Directly obtains a parallel stream from a `Collection`, equivalent to `.stream().parallel()`.

```java
long count2 = numbers.parallelStream().filter(n -> n % 2 == 0).count();
```

## 3. `sequential()`

Converts a stream back to sequential — useful mid-pipeline if a specific operation must run in order (the stream's parallel/sequential mode is a single flag re-evaluated at each operation, not locked in permanently).

```java
numbers.parallelStream()
       .sequential() // subsequent ops run sequentially
       .forEach(System.out::println);
```

## 4. `isParallel()`

Checks the stream's current mode.

```java
Stream<Integer> s = numbers.parallelStream();
System.out.println(s.isParallel()); // true
```

## 5. `ForkJoinPool`

Parallel streams execute on the shared **common `ForkJoinPool`** (`ForkJoinPool.commonPool()`, sized to `Runtime.availableProcessors() - 1` worker threads by default) using the fork/join work-stealing algorithm — the same pool `CompletableFuture`'s default async methods use.

```java
System.out.println(ForkJoinPool.commonPool().getParallelism()); // e.g., 7 on an 8-core machine

// Running a parallel stream on a CUSTOM pool instead of the shared common pool:
ForkJoinPool customPool = new ForkJoinPool(4);
try {
    customPool.submit(() ->
        numbers.parallelStream().filter(n -> n % 2 == 0).count()
    ).get();
} finally {
    customPool.shutdown();
}
```

**⚠️ Warning:** blocking I/O inside a parallel stream's lambda ties up shared common-pool threads, potentially starving *other unrelated* parallel streams or `CompletableFuture` tasks elsewhere in the same JVM that also rely on the common pool.

## 6. Ordering

Parallel streams **preserve encounter order for order-sensitive operations** (`forEachOrdered`, `collect(Collectors.toList())`, `findFirst`) — but plain `forEach()` does **not** guarantee order, since imposing it would defeat the point of parallelism.

```java
// Order NOT guaranteed
List.of(1, 2, 3, 4, 5).parallelStream().forEach(System.out::println);

// Order IS guaranteed (at a performance cost)
List.of(1, 2, 3, 4, 5).parallelStream().forEachOrdered(System.out::println); // always 1,2,3,4,5
```

Calling `.unordered()` (Module 5) before a parallel operation can let the runtime skip order-preservation bookkeeping, improving performance when order genuinely doesn't matter.

## 7. Thread Safety

The stream pipeline itself is thread-safe internally, but **your lambdas must not mutate shared, non-thread-safe state** — this is a very common source of bugs.

```java
// BUG — ArrayList is not thread-safe; concurrent add() calls corrupt it
List<Integer> unsafe = new ArrayList<>();
numbers.parallelStream().forEach(unsafe::add); // may throw or silently lose elements

// FIX — use collect(), which handles parallel accumulation correctly
List<Integer> safe = numbers.parallelStream().collect(Collectors.toList());
```

## 8. Performance

Parallel streams are **not automatically faster**. They help when:
- The dataset is **large** (overhead of splitting/merging is only worth it past a certain size).
- The per-element work is **CPU-bound and substantial** (not trivial operations).
- The source **splits efficiently** — arrays and `ArrayList` split well; `LinkedList` and `Stream.iterate()`-based sources split poorly (Module 13's `Spliterator`).

```java
// Benchmark sketch — measure both and compare for YOUR actual data size/workload
long start = System.nanoTime();
long sum1 = LongStream.rangeClosed(1, 100_000_000L).sum();
System.out.println("Sequential: " + (System.nanoTime() - start));

start = System.nanoTime();
long sum2 = LongStream.rangeClosed(1, 100_000_000L).parallel().sum();
System.out.println("Parallel: " + (System.nanoTime() - start));
```

**Rule of thumb:** don't reach for `.parallel()` by default — measure first. For small collections or I/O-bound work, sequential streams are often faster once you account for thread coordination overhead.

---

**Next: Module 13 — Advanced Stream Concepts** (stateful vs stateless ops, short-circuiting, Spliterator, custom collectors).
