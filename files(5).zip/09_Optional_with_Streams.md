# Module 9 — Optional with Streams

> Part of: **Java Stream API — Complete Reference Guide**
> Many stream terminal operations (`findFirst`, `min`, `max`, `reduce`) can't guarantee a result exists (empty stream case) — they return an `Optional` wrapper instead of risking `null` or throwing.

---

## 1. `Optional<T>`

A container that may or may not hold a non-null value — forces the caller to explicitly handle the "no value" case instead of risking a `NullPointerException`.

```java
Optional<Integer> max = Stream.of(3, 1, 4).max(Integer::compareTo);

// Safe consumption patterns:
System.out.println(max.isPresent() ? max.get() : "none");   // works, but verbose
System.out.println(max.orElse(-1));                            // 4, or -1 if empty
System.out.println(max.orElseGet(() -> computeDefault()));       // lazy default
max.ifPresent(v -> System.out.println("Found: " + v));            // functional-style consumption
max.ifPresentOrElse(
    v -> System.out.println("Found: " + v),
    () -> System.out.println("Nothing found")
);
Integer required = max.orElseThrow(() -> new NoSuchElementException("empty!"));
```

**Chaining Optional itself with map/filter:**

```java
Optional<Integer> max2 = Stream.of(3, 1, 4).max(Integer::compareTo);
Optional<String> label = max2.map(v -> "Max is " + v);
System.out.println(label.orElse("no max")); // Max is 4
```

## 2. `OptionalInt`

The primitive-specialized equivalent, returned by `IntStream` operations (`min()`, `max()`, `findFirst()`, `average()` — the last actually returns `OptionalDouble`, see below). Avoids boxing.

```java
OptionalInt maxInt = IntStream.of(3, 1, 4).max();
System.out.println(maxInt.getAsInt());       // 4 (note: getAsInt(), not get()!)
System.out.println(maxInt.orElse(-1));
```

## 3. `OptionalLong`

Same idea for `LongStream`.

```java
OptionalLong maxLong = LongStream.of(300L, 100L, 400L).max();
System.out.println(maxLong.getAsLong());
```

## 4. `OptionalDouble`

Same idea for `DoubleStream` — also what `average()` returns on **any** primitive stream (`IntStream.average()` too, since an average is inherently a floating-point result even for integer input).

```java
OptionalDouble avg = IntStream.of(1, 2, 3, 4).average();
System.out.println(avg.getAsDouble()); // 2.5
```

## Key Distinctions (frequently tested)

| Type | Retrieval method | Returned by |
|---|---|---|
| `Optional<T>` | `.get()` | `Stream<T>.findFirst()`, `.max()`, `.min()`, `.reduce()` |
| `OptionalInt` | `.getAsInt()` | `IntStream.max()`, `.min()`, `.findFirst()` |
| `OptionalLong` | `.getAsLong()` | `LongStream.max()`, `.min()`, `.findFirst()` |
| `OptionalDouble` | `.getAsDouble()` | `DoubleStream.max()`/`.min()`, and **average() on every stream type** |

**Common mistake:** calling `.get()` on an `OptionalInt` — it doesn't have that method; it's `.getAsInt()`. This asymmetry between `Optional<T>` and the primitive `Optional*` types is a frequent compile-error trap for those switching between them.

## Anti-Pattern: `Optional.get()` Without Checking

```java
// RISKY — throws NoSuchElementException if the stream was empty
int value = Stream.of(1, 2, 3).filter(n -> n > 10).findFirst().get(); // BOOM

// SAFE
int safeValue = Stream.of(1, 2, 3).filter(n -> n > 10).findFirst().orElse(-1);
```

---

**Next: Module 10 — Stream + Lambda** (the functional interfaces that power every lambda passed into a stream operation).
