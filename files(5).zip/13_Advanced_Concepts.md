# Module 13 — Advanced Stream Concepts

> Part of: **Java Stream API — Complete Reference Guide**

---

## 1. Stateful Operations

Operations that need to remember information from **previously seen elements** to correctly process the current one. They cannot process each element in complete isolation.

```java
// distinct() — must remember every element seen so far to detect duplicates
// sorted()   — must see ALL elements before emitting even the first result
// limit()    — must track how many have passed through so far
Stream.of(3, 1, 2, 1, 3).distinct().forEach(System.out::println); // 3, 1, 2
```

**Consequence:** stateful operations can hurt parallel performance (they may require synchronization or full buffering) and can turn an otherwise-infinite-stream-friendly pipeline into one that hangs — e.g., `Stream.iterate(1, n -> n+1).sorted()` never terminates, since `sorted()` must see every element first, but the stream is infinite.

## 2. Stateless Operations

Process each element independently, with no memory of prior elements — ideal for parallelism.

```java
// filter(), map(), peek() — pure per-element, no shared state needed
Stream.of(1, 2, 3).map(n -> n * 2).forEach(System.out::println); // 2, 4, 6
```

## 3. Short-Circuit Operations

Can produce a result **without processing the entire stream** — essential for working with infinite streams.

```java
// Intermediate short-circuit: limit()
Stream.iterate(1, n -> n + 1).limit(5).forEach(System.out::println); // stops after 5, even though source is infinite

// Terminal short-circuit: anyMatch(), findFirst(), findAny()
boolean found = Stream.iterate(1, n -> n + 1).anyMatch(n -> n == 100); // stops as soon as 100 is found
```

Without at least one short-circuiting operation, an infinite stream (`Stream.generate`/`Stream.iterate`) will **never terminate**.

## 4. Ordered Streams

A stream has an **encounter order** if its source does (e.g., a `List`, an array, `Stream.of()`, a range). Order-sensitive operations (`findFirst`, `limit`, `sorted`, `forEachOrdered`) respect this order.

```java
List.of(1, 2, 3).stream().findFirst(); // deterministic: always 1
```

## 5. Unordered Streams

Sources like `HashSet` have **no defined encounter order** — order-sensitive operations still "work" but their result may vary between runs (whatever iteration order the `HashSet` happens to produce). `.unordered()` (Module 5) explicitly discards ordering constraints even for an otherwise-ordered source, which can improve performance (especially in parallel).

```java
Set<Integer> hashSet = new HashSet<>(List.of(3, 1, 2));
hashSet.stream().findFirst(); // "first" is whatever HashSet's internal order happens to be — not guaranteed 1
```

## 6. Infinite Streams

Created via `Stream.generate()` or `Stream.iterate()` (2-arg form) — must be paired with a short-circuiting operation (`limit`, or the 9+ `takeWhile`/3-arg `iterate`) or the pipeline never completes.

```java
Stream.generate(() -> "x").limit(3).forEach(System.out::println); // x, x, x
```

## 7. Stream Reuse

A stream can be traversed by a terminal operation **exactly once**. Any further operation on the same stream instance throws `IllegalStateException`.

```java
Stream<Integer> s = Stream.of(1, 2, 3);
s.forEach(System.out::println);
s.count(); // throws IllegalStateException: stream has already been operated upon or closed
```

**Fix:** create a new stream from the source each time you need to traverse it again (e.g., call `.stream()` again on the original collection).

## 8. Side Effects

Stream operations are meant to be free of side effects on shared mutable state — modifying external variables from within a lambda breaks the functional contract and is **explicitly unsafe** for parallel streams (race conditions).

```java
// BAD — side effect on external mutable state, breaks under parallel()
int[] counter = {0}; // array trick to mutate an "effectively final" variable
Stream.of(1, 2, 3).parallel().forEach(n -> counter[0]++); // RACE CONDITION

// GOOD — no side effects; use a proper terminal operation designed for aggregation
long count = Stream.of(1, 2, 3).parallel().count();
```

## 9. `Spliterator<T>`

The underlying traversal-**and-splitting** abstraction that powers both sequential and parallel stream execution — think "Iterator that also knows how to divide itself in half" (covered in more depth with code in the concurrency-focused material, but summarized here for stream purposes).

```java
Spliterator<Integer> spliterator = List.of(1, 2, 3, 4).spliterator();
Spliterator<Integer> half = spliterator.trySplit(); // splits the source for parallel processing

if (half != null) half.forEachRemaining(System.out::println);
spliterator.forEachRemaining(System.out::println);
```

**Why it matters for streams:** how well a source's `Spliterator` splits (cheaply, evenly, with an accurately estimable size) directly determines how well `.parallel()` actually performs for that source — `ArrayList`/arrays split very well; `LinkedList` and I/O-based sources split poorly or not at all.

## 10. Custom Collectors

You can implement `Collector<T,A,R>` directly for fully custom accumulation logic, or (more commonly) use `Collector.of(...)` for a lightweight custom collector without a full class.

```java
Collector<String, StringBuilder, String> customJoiner = Collector.of(
        StringBuilder::new,                          // supplier: create the accumulator
        (sb, s) -> sb.append(s).append("|"),           // accumulator: fold one element in
        StringBuilder::append,                          // combiner: merge two accumulators (parallel streams)
        StringBuilder::toString                          // finisher: convert accumulator to final result
);

String result = Stream.of("a", "b", "c").collect(customJoiner);
System.out.println(result); // a|b|c|
```

---

**Next: Module 14 — Interview Problem Patterns** (the classic stream-based coding questions, fully solved).
