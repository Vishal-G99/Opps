# Module 7 — Primitive Stream Operations

> Part of: **Java Stream API — Complete Reference Guide**
> These methods exist **only** on `IntStream`/`LongStream`/`DoubleStream` — `Stream<T>` doesn't have them, since summing/averaging arbitrary objects makes no general sense.

---

## 1. `sum()`

Total of all elements. Available on `IntStream` (→ `int`), `LongStream` (→ `long`), `DoubleStream` (→ `double`). **Not** available on `Stream<T>`.

```java
int total = IntStream.of(1, 2, 3, 4).sum(); // 10
```

## 2. `average()`

Returns an `OptionalDouble` (empty if the stream is empty).

```java
OptionalDouble avg = IntStream.of(2, 4, 6).average();
System.out.println(avg.getAsDouble()); // 4.0
```

## 3. `min()` / `max()` (primitive versions)

Return `OptionalInt`/`OptionalLong`/`OptionalDouble` — no `Comparator` needed since natural numeric ordering is used.

```java
OptionalInt min = IntStream.of(5, 2, 8).min();
OptionalInt max = IntStream.of(5, 2, 8).max();
System.out.println(min.getAsInt() + " " + max.getAsInt()); // 2 8
```

## 4. `count()`

Same as the general `Stream` version — number of elements as `long`.

```java
long count = IntStream.range(0, 100).filter(n -> n % 2 == 0).count(); // 50
```

## 5. `summaryStatistics()`

Computes count, sum, min, max, and average **in a single pass** — far more efficient than calling each separately (which would each re-traverse).

```java
IntSummaryStatistics stats = IntStream.of(4, 8, 15, 16, 23, 42).summaryStatistics();
System.out.println(stats);
// IntSummaryStatistics{count=6, sum=108, min=4, average=18.000000, max=42}
```

## 6. `boxed()`

Converts a primitive stream to its boxed `Stream<Wrapper>` equivalent — needed when you want to use `Stream<T>`-only operations (like `collect(Collectors.toList())` into a `List<Integer>`) or store results in a generic collection.

```java
List<Integer> list = IntStream.range(1, 5).boxed().collect(Collectors.toList());
System.out.println(list); // [1, 2, 3, 4]
```

## 7. `mapToObj(IntFunction<R>)`

Converts a primitive stream to a `Stream<R>` via a mapping function (more flexible than `boxed()`, which only wraps as-is).

```java
Stream<String> labels = IntStream.range(1, 4).mapToObj(i -> "item-" + i);
labels.forEach(System.out::println); // item-1, item-2, item-3
```

## 8. `asLongStream()` / `asDoubleStream()`

Widening conversions between primitive stream types (matches Java's own primitive widening rules: `int` → `long` → `double`).

```java
LongStream longs = IntStream.range(1, 5).asLongStream();
DoubleStream doubles = IntStream.range(1, 5).asDoubleStream();
```

**Note:** there's no `asIntStream()` on `LongStream`/`DoubleStream` — narrowing conversions aren't provided automatically, since they can lose data; you'd use `mapToInt()` explicitly if you really need that (accepting the possible truncation).

---

**Next: Module 8 — Collectors** (every method in the `Collectors` utility class, the terminal-reduction workhorse of the Stream API).
