# Module 6 — Terminal Operations

> Part of: **Java Stream API — Complete Reference Guide**
> Terminal operations **trigger execution** and consume the stream — after any one of these runs, the stream cannot be reused.

---

## 1. `forEach(Consumer<T>)`

Performs an action per element. **Order is not guaranteed for parallel streams.**

```java
Stream.of("a", "b", "c").forEach(System.out::println);
```

## 2. `forEachOrdered(Consumer<T>)`

Like `forEach`, but **guarantees encounter order** even for parallel streams (at the cost of losing parallelism's performance benefit for this step).

```java
Stream.of("a", "b", "c").parallel().forEachOrdered(System.out::println); // always a, b, c
```

## 3. `toArray()`

Collects elements into an array.

```java
Object[] arr = Stream.of(1, 2, 3).toArray();
Integer[] typedArr = Stream.of(1, 2, 3).toArray(Integer[]::new); // with array constructor reference
```

## 4. `reduce()`

Combines all elements into a single result using an accumulator function. Three overloads:

```java
// 1-arg: no identity, returns Optional<T> (empty if stream is empty)
Optional<Integer> sum1 = Stream.of(1, 2, 3).reduce((a, b) -> a + b);
System.out.println(sum1.get()); // 6

// 2-arg: identity value provided, returns T directly (never empty)
int sum2 = Stream.of(1, 2, 3).reduce(0, (a, b) -> a + b);
System.out.println(sum2); // 6

// 3-arg: identity + accumulator + combiner (needed for parallel streams changing type)
int totalLength = Stream.of("a", "bb", "ccc")
        .reduce(0, (partialSum, str) -> partialSum + str.length(), Integer::sum);
System.out.println(totalLength); // 6
```

## 5. `collect()`

The most flexible terminal operation — accumulates elements into a container using a `Collector` (Module 8).

```java
List<String> list = Stream.of("a", "b").collect(Collectors.toList());
```

## 6. `min(Comparator<T>)` / `max(Comparator<T>)`

Returns the minimum/maximum element as an `Optional<T>` (empty if the stream is empty).

```java
Optional<Integer> min = Stream.of(5, 3, 8, 1).min(Integer::compareTo);
Optional<Integer> max = Stream.of(5, 3, 8, 1).max(Integer::compareTo);
System.out.println(min.get() + " " + max.get()); // 1 8
```

## 7. `count()`

Returns the number of elements as a `long`.

```java
long count = Stream.of(1, 2, 3).filter(n -> n > 1).count(); // 2
```

## 8. `anyMatch(Predicate<T>)`

Returns `true` if **at least one** element matches. **Short-circuiting** — stops at the first match.

```java
boolean hasEven = Stream.of(1, 3, 4, 5).anyMatch(n -> n % 2 == 0); // true
```

## 9. `allMatch(Predicate<T>)`

Returns `true` if **every** element matches (vacuously `true` for an empty stream). Short-circuits on the first failure.

```java
boolean allPositive = Stream.of(1, 2, 3).allMatch(n -> n > 0); // true
```

## 10. `noneMatch(Predicate<T>)`

Returns `true` if **no** element matches. Short-circuits on the first match found.

```java
boolean noNegatives = Stream.of(1, 2, 3).noneMatch(n -> n < 0); // true
```

## 11. `findFirst()`

Returns the first element as `Optional<T>`, respecting encounter order — deterministic even on parallel streams.

```java
Optional<Integer> first = Stream.of(3, 1, 4).filter(n -> n > 1).findFirst();
System.out.println(first.get()); // 3
```

## 12. `findAny()`

Returns **any** element as `Optional<T>` — no ordering guarantee. On a parallel stream, this can be faster than `findFirst()` since any thread finishing first can return.

```java
Optional<Integer> any = Stream.of(3, 1, 4).parallel().filter(n -> n > 1).findAny();
```

---

**Next: Module 7 — Primitive Stream Operations** (sum, average, summaryStatistics, boxed, and primitive-specific conversions).
