# Module 2 — Stream Architecture

> Part of: **Java Stream API — Complete Reference Guide**

---

## Overview

```
   SOURCE                INTERMEDIATE OPS                    TERMINAL OP
┌───────────┐        ┌─────────┐  ┌─────────┐              ┌───────────┐
│ Collection │──────▶│ filter() │─▶│  map()   │─▶ ... ─────▶│ collect() │──▶ Result
│  / Array   │        └─────────┘  └─────────┘              └───────────┘
│  / I/O     │
└───────────┘
   (lazy pipeline built here, nothing executes)      (execution triggered HERE)
```

## 1. Source

Where stream elements originate. Common sources: collections (`list.stream()`), arrays (`Arrays.stream(arr)`), static factories (`Stream.of(...)`), generator functions (`Stream.generate(...)`), and I/O (`Files.lines(path)`).

```java
Stream<String> fromList = List.of("a", "b").stream();
Stream<Integer> fromArray = Arrays.stream(new Integer[]{1, 2, 3});
Stream<Integer> fromValues = Stream.of(10, 20, 30);
```

## 2. Intermediate Operations

Transform one stream into another stream. **Lazy** — they don't execute until a terminal op is invoked. Always return a `Stream` (or primitive stream), so they can be chained.

```java
Stream<Integer> pipeline = Stream.of(1, 2, 3, 4, 5)
        .filter(n -> n > 1)   // returns Stream<Integer>
        .map(n -> n * 10);    // returns Stream<Integer>
// nothing has executed yet — pipeline is just a description
```

## 3. Terminal Operation

Triggers actual execution of the entire pipeline and produces a non-stream result (a value, a collection, void, etc.). **A stream can have only one terminal operation, and after it runs, the stream is consumed** — calling any operation on it again throws `IllegalStateException`.

```java
List<Integer> result = pipeline.collect(Collectors.toList()); // NOW it executes: [20, 30, 40, 50]
```

## 4. The Full Pipeline — Element-by-Element Execution Model

A crucial, frequently misunderstood detail: streams do **not** process all elements through stage 1, then all through stage 2, etc. Instead, each element flows through the **entire** pipeline (all intermediate ops, then the terminal op's per-element action) before the next element starts. This is why `peek()`-based tracing shows interleaved output.

```java
Stream.of(1, 2, 3)
    .filter(n -> { System.out.println("filter " + n); return true; })
    .map(n -> { System.out.println("map " + n); return n * 2; })
    .forEach(n -> System.out.println("forEach " + n));
```

**Output (element-by-element, NOT stage-by-stage):**
```
filter 1
map 1
forEach 2
filter 2
map 2
forEach 4
filter 3
map 3
forEach 6
```

This "vertical" execution model is what enables short-circuiting (`limit()`, `findFirst()`) to stop processing early without touching every element — if elements were processed stage-by-stage, short-circuiting would be impossible to implement efficiently.

---

**Next: Module 3 — Stream Types** (Stream&lt;T&gt;, IntStream, LongStream, DoubleStream — plus the missing root type, BaseStream).
