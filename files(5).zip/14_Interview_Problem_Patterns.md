# Module 14 — Interview Problem Patterns

> Part of: **Java Stream API — Complete Reference Guide**
> Shared sample dataset for the "employee" problems:

```java
record Employee(String name, String department, double salary) {}

List<Employee> employees = List.of(
    new Employee("Alice", "Engineering", 95000),
    new Employee("Bob", "Engineering", 85000),
    new Employee("Charlie", "Sales", 65000),
    new Employee("Dave", "Sales", 70000),
    new Employee("Eve", "HR", 60000),
    new Employee("Frank", "Engineering", 95000) // duplicate salary with Alice, deliberately
);
```

---

## 1. Second Highest (Salary)

```java
Optional<Double> secondHighest = employees.stream()
        .map(Employee::salary)
        .distinct()
        .sorted(Comparator.reverseOrder())
        .skip(1)
        .findFirst();
System.out.println(secondHighest.orElse(-1.0)); // 85000.0
```
**Key idea:** `distinct()` before sorting/skipping avoids treating tied top salaries as separate ranks.

## 2. Duplicate Elements

```java
List<Integer> nums = List.of(1, 2, 3, 2, 4, 3, 5);

Set<Integer> seen = new HashSet<>();
List<Integer> duplicates = nums.stream()
        .filter(n -> !seen.add(n)) // add() returns false if already present
        .distinct()
        .collect(Collectors.toList());
System.out.println(duplicates); // [2, 3]
```

## 3. Frequency (Count Occurrences)

```java
Map<Integer, Long> frequency = nums.stream()
        .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
System.out.println(frequency); // {1=1, 2=2, 3=2, 4=1, 5=1}
```

## 4. Grouping

```java
Map<String, List<Employee>> byDept = employees.stream()
        .collect(Collectors.groupingBy(Employee::department));
System.out.println(byDept.keySet()); // [Engineering, Sales, HR]
```

## 5. Highest Salary (Overall)

```java
Optional<Employee> highest = employees.stream()
        .max(Comparator.comparingDouble(Employee::salary));
System.out.println(highest.get().name()); // Alice (or Frank — tied; max() returns whichever is encountered first for equal comparisons... actually returns the LAST max found by spec)
```
**Note:** `max()`/`min()` with ties returns *some* element with the extreme value, not necessarily a specific one — don't rely on which one for tied values unless you add a secondary tiebreaker comparator.

## 6. Department-wise Highest Salary

```java
Map<String, Optional<Employee>> highestByDept = employees.stream()
        .collect(Collectors.groupingBy(
                Employee::department,
                Collectors.maxBy(Comparator.comparingDouble(Employee::salary))));

highestByDept.forEach((dept, emp) ->
        System.out.println(dept + " -> " + emp.map(Employee::name).orElse("none")));
// Engineering -> Alice (or Frank)
// Sales -> Dave
// HR -> Eve
```

**Cleaner variant avoiding nested Optional** (using `collectingAndThen`):

```java
Map<String, Employee> highestByDeptClean = employees.stream()
        .collect(Collectors.groupingBy(
                Employee::department,
                Collectors.collectingAndThen(
                        Collectors.maxBy(Comparator.comparingDouble(Employee::salary)),
                        Optional::get)));
```

## 7. First Non-Repeated Character

```java
String input = "swiss";

Character firstNonRepeated = input.chars()
        .mapToObj(c -> (char) c)
        .collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()))
        .entrySet().stream()
        .filter(e -> e.getValue() == 1)
        .map(Map.Entry::getKey)
        .findFirst()
        .orElse(null);
System.out.println(firstNonRepeated); // w
```
**Key idea:** `LinkedHashMap::new` as the map-factory overload of `groupingBy` preserves insertion (i.e., first-seen character) order, which is essential here.

## 8. First Repeated Character

```java
Set<Character> seenChars = new LinkedHashSet<>();
Character firstRepeated = input.chars()
        .mapToObj(c -> (char) c)
        .filter(c -> !seenChars.add(c))
        .findFirst()
        .orElse(null);
System.out.println(firstRepeated); // s
```

## 9. Anagram Check

```java
String a = "listen", b = "silent";

boolean isAnagram = a.length() == b.length() &&
        a.chars().sorted().boxed().toList()
         .equals(b.chars().sorted().boxed().toList());
System.out.println(isAnagram); // true
```

## 10. Palindrome Check

```java
String word = "racecar";

boolean isPalindrome = IntStream.range(0, word.length() / 2)
        .allMatch(i -> word.charAt(i) == word.charAt(word.length() - 1 - i));
System.out.println(isPalindrome); // true
```

## 11. Top N (e.g., Top 2 Highest-Paid Employees)

```java
List<Employee> top2 = employees.stream()
        .sorted(Comparator.comparingDouble(Employee::salary).reversed())
        .limit(2)
        .collect(Collectors.toList());
top2.forEach(e -> System.out.println(e.name() + " " + e.salary()));
// Alice 95000.0 (or Frank)
// Frank 95000.0 (or Alice)
```

## 12. Sorting (Multi-Level)

```java
List<Employee> sorted = employees.stream()
        .sorted(Comparator.comparing(Employee::department)
                           .thenComparing(Employee::salary, Comparator.reverseOrder()))
        .collect(Collectors.toList());
// Sorted by department alphabetically, then by salary descending within each department
```

## 13. Partitioning (High vs Low Earners)

```java
Map<Boolean, List<Employee>> partitioned = employees.stream()
        .collect(Collectors.partitioningBy(e -> e.salary() >= 80000));
System.out.println("High earners: " + partitioned.get(true).size());  // 3
System.out.println("Low earners: " + partitioned.get(false).size());  // 3
```

## 14. Flattening (Nested Lists)

```java
List<List<Integer>> nested = List.of(List.of(1, 2, 3), List.of(4, 5), List.of(6));

List<Integer> flat = nested.stream()
        .flatMap(List::stream)
        .collect(Collectors.toList());
System.out.println(flat); // [1, 2, 3, 4, 5, 6]
```

## 15. Joining (Formatted Output)

```java
String summary = employees.stream()
        .map(e -> e.name() + " ($" + e.salary() + ")")
        .collect(Collectors.joining(", ", "Employees: [", "]"));
System.out.println(summary);
// Employees: [Alice ($95000.0), Bob ($85000.0), ...]
```

## 16. Statistics (Salary Summary)

```java
DoubleSummaryStatistics stats = employees.stream()
        .collect(Collectors.summarizingDouble(Employee::salary));
System.out.printf("Count=%d Sum=%.2f Min=%.2f Max=%.2f Avg=%.2f%n",
        stats.getCount(), stats.getSum(), stats.getMin(), stats.getMax(), stats.getAverage());
// Count=6 Sum=470000.00 Min=60000.00 Max=95000.00 Avg=78333.33
```

## 17. Complex Multi-Step Pipeline (Combining Several Patterns)

**Problem:** For each department, find the average salary, but only among employees earning above the company-wide average, sorted by department name.

```java
double companyAvg = employees.stream()
        .collect(Collectors.averagingDouble(Employee::salary)); // 78333.33

Map<String, Double> result = employees.stream()
        .filter(e -> e.salary() > companyAvg)
        .collect(Collectors.groupingBy(
                Employee::department,
                TreeMap::new, // sorted by department name automatically
                Collectors.averagingDouble(Employee::salary)));

result.forEach((dept, avg) -> System.out.printf("%s: %.2f%n", dept, avg));
// Engineering: 91666.67
```

**This single problem exercises:** `averagingDouble` (standalone), `filter`, `groupingBy` with a **map-factory overload** (`TreeMap::new`) for automatic sorting, and `averagingDouble` again as a **downstream collector** — a realistic composite of everything covered in Modules 5–8.

---

## Closing Note

This completes the 14-module Java Stream API reference — Fundamentals and Architecture (Modules 1–2), the full type system including the two types missing from the original roadmap (Module 3), every creation method (Module 4), every intermediate and terminal operation (Modules 5–6), primitive stream specifics (Module 7), the complete `Collectors` toolkit (Module 8), `Optional` handling (Module 9), the functional interfaces and method reference forms underpinning every lambda (Modules 10–11), parallel execution mechanics (Module 12), advanced internals (Module 13), and finally the classic interview problem patterns solved end-to-end (Module 14). The fastest way to solidify this: re-solve every problem in this module from memory without looking at the answer, then explain out loud why each pattern (grouping-with-downstream-collector, distinct-before-sort, LinkedHashMap-for-order-preservation) is the right tool for that specific problem shape.
