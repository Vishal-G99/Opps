# Module 1 — Stream API Fundamentals

> Part of: **Java Stream API — Complete Reference Guide**

---

## 1. What is a Stream?

A **Stream** (`java.util.stream.Stream<T>`) is a sequence of elements supporting **functional-style, declarative** operations — you describe *what* transformation you want, not *how* to loop and do it. A stream is **not** a data structure; it doesn't store elements. It's a pipeline that pulls elements from a source (a collection, array, generator, I/O channel) and processes them on demand.

```java
List<String> names = List.of("Alice", "Bob", "Charlie");

long count = names.stream()               // source
                   .filter(n -> n.length() > 3)  // intermediate
                   .count();                      // terminal

System.out.println(count); // 2
```

## 2. Why Stream API?

Before Java 8, processing a collection meant writing explicit loops with mutable accumulator variables — verbose, error-prone (off-by-one, wrong mutation), and hard to parallelize safely.

```java
// Pre-Java 8 imperative style
List<String> result = new ArrayList<>();
for (String name : names) {
    if (name.length() > 3) {
        result.add(name.toUpperCase());
    }
}

// Stream API — declarative, same result
List<String> result2 = names.stream()
        .filter(n -> n.length() > 3)
        .map(String::toUpperCase)
        .collect(Collectors.toList());
```

**Benefits:** conciseness, readability, built-in parallelism (`.parallel()`), composability (chain many operations fluently), and reduced mutable state (fewer bugs from shared mutation).

## 3. Stream vs Collection

| Aspect | Collection | Stream |
|---|---|---|
| Stores elements | Yes | No — computes on demand |
| Iteration | External (you write the loop) | Internal (the stream iterates for you) |
| Reusable | Yes, indefinitely | No — consumed once, then unusable |
| Mutation | Can add/remove elements | Never modifies the source |
| Evaluation | Eager (built fully upfront) | Lazy (nothing runs until a terminal op) |
| Size known upfront | Yes | Not necessarily (e.g., infinite streams) |

```java
List<Integer> list = new ArrayList<>(List.of(1, 2, 3));
list.add(4); // fine — collections are mutable and reusable

Stream<Integer> stream = list.stream();
stream.forEach(System.out::println);
stream.forEach(System.out::println); // throws IllegalStateException — stream already consumed
```

## 4. Stream Pipeline

A pipeline = **one source** + **zero or more intermediate operations** + **exactly one terminal operation**.

```
list.stream()          <- SOURCE
    .filter(...)        <- INTERMEDIATE (lazy, returns a new Stream)
    .map(...)            <- INTERMEDIATE (lazy, returns a new Stream)
    .collect(...);        <- TERMINAL (eager, triggers execution, produces a result)
```

Nothing actually executes until the terminal operation is called — intermediate operations just build up a description of the pipeline.

## 5. Lazy Evaluation

Intermediate operations are **lazy**: they don't process any elements until a terminal operation demands a result. This enables short-circuiting and avoids unnecessary work.

```java
List<Integer> numbers = List.of(1, 2, 3, 4, 5);

Stream<Integer> pipeline = numbers.stream()
        .filter(n -> {
            System.out.println("filtering " + n);
            return n % 2 == 0;
        });

System.out.println("Pipeline built, nothing printed yet");
long count = pipeline.count(); // NOW filtering prints, for each element
```

**Output:**
```
Pipeline built, nothing printed yet
filtering 1
filtering 2
filtering 3
filtering 4
filtering 5
```

Note: `count()` may sometimes skip actually filtering each element if the stream can compute size without traversal (an internal optimization) — but conceptually, nothing runs before the terminal call.

## 6. Internal Iteration

The stream itself controls *how* iteration happens (looping strategy, potential parallelization) — you just supply *what* to do per element via a lambda. Contrast with external iteration (`for`/`Iterator`), where **you** control the loop mechanics.

```java
// External iteration — YOU drive the loop
for (String name : names) {
    System.out.println(name);
}

// Internal iteration — the STREAM drives the loop
names.stream().forEach(System.out::println);
```

Internal iteration is what allows the same pipeline to run sequentially or in parallel without you rewriting any loop logic — the stream implementation decides.

## 7. Functional Programming Style

Streams encourage **pure functions** (no side effects, output depends only on input) and **immutability** (never mutate the source or shared state from within a lambda passed to a stream operation).

```java
// Functional style — pure, no side effects
List<Integer> doubled = numbers.stream()
        .map(n -> n * 2)
        .collect(Collectors.toList());

// AVOID — side-effecting lambda (works, but breaks the functional contract)
List<Integer> sink = new ArrayList<>();
numbers.stream().forEach(sink::add); // discouraged; use collect() instead
```

## 8. Non-Interference

The stream source must **not be modified** while the stream is being processed (for non-concurrent sources). Doing so risks `ConcurrentModificationException` or undefined behavior.

```java
List<Integer> source = new ArrayList<>(List.of(1, 2, 3, 4));

source.stream().forEach(n -> {
    if (n == 2) {
        source.remove(Integer.valueOf(3)); // BUG: mutating source during traversal
    }
    System.out.println(n);
}); // throws ConcurrentModificationException (behavior is officially unspecified/risky)
```

**Rule:** never mutate the underlying source collection from within a lambda passed to any stream operation on that same stream.

---

**Next: Module 2 — Stream Architecture** (Source, Intermediate Operations, Terminal Operation, Pipeline mechanics in depth).
